import lightkurve as lk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.ticker import MultipleLocator
from matplotlib.ticker import FixedLocator
from matplotlib.ticker import LogFormatter, LogLocator
from multiprocessing import Pool
import os
import time as tm
import corner
import emcee
from scipy.stats import gaussian_kde


rcParams["savefig.dpi"] = 300
rcParams['font.size'] = 8

gTeff=[]
gTeff_1_by_S2=[]

gMass=[]
gMass_1_by_S2=[]

gAge=[]
gAge_1_by_S2=[]

gR=[]
gR_1_by_S2=[]

gZ=[]
gZ_1_by_S2=[]

gLogg=[]
gLogg_1_by_S2=[]

gColor=[]
gLabel=[]

def calc_one_by_s2(f_corr, f_obs):
	k = len(f_corr)
	sum=0
	for i in range(k):
		sum += (f_corr[i]-f_obs[i])**2

	one_by_s2 = k / sum
	return one_by_s2

def analysis_one(filepath, filter=False, color='k', label=-1):
	with open(filepath, 'r', encoding='utf-8') as file:
		lines = file.readlines()

		f_corr=[]
		f_obs=[]
		for line in lines:
			if 'chi2term' in line:
				continue
			words = line.split()
			if len(words) <= 1:
				continue
			if len(words) == 7:
				f_corr.append(float(words[3]))
				f_obs.append(float(words[4]))
			if words[0] == 'Teff':
				one_by_S2 = calc_one_by_s2(f_corr, f_obs)
				Teff = float(words[1])
				if Teff < 8400 or Teff > 9500:
					return

			if words[0] == 'initial_mass':
				Mass = float(words[1])
				
			if words[0] == 'age':
				Age = float(words[1])/1e9
				
			if words[0] == 'log_R':
				R = 10**float(words[1])

			if words[0] == 'initial_Z':
				Z = float(words[1])

			if words[0] == 'log_g':
				logg=float(words[1])

		gTeff_1_by_S2.append( one_by_S2)
		gMass_1_by_S2.append(one_by_S2)
		gR_1_by_S2.append(one_by_S2)
		gAge_1_by_S2.append(one_by_S2)
		gZ_1_by_S2.append(one_by_S2)
		gLogg_1_by_S2.append(one_by_S2)
		gTeff.append(Teff)
		gMass.append(Mass)
		gAge.append(Age)
		gR.append(R)
		gZ.append(Z)
		gLogg.append(logg)
		gColor.append(color)
		gLabel.append(label)


#This equation is from OriginPro
def Gaussian_model(x, theta):
	T0,sigma,coef,y0 = theta
	phase_x=np.array((x-T0))
	coefficient = 1 / (sigma * np.sqrt(np.pi/2))
	exponent = -2 * (phase_x / sigma) ** 2
	
	return y0 + coef * coefficient* np.exp(exponent) 



def plot_env():
	global gTeff,gTeff_1_by_S2,gMass,gMass_1_by_S2,gZ,gZ_1_by_S2,gAge,gAge_1_by_S2,gR,gR_1_by_S2
	Teff = np.array(gTeff)
	Teff_1_by_S2 = np.array(gTeff_1_by_S2)
	Mass = np.array(gMass)
	Mass_1_by_S2 = np.array(gMass_1_by_S2)
	Z = np.array(gZ)
	Z_1_by_S2 = np.array(gZ_1_by_S2)
	Age = np.array(gAge)
	Age_1_by_S2 = np.array(gAge_1_by_S2)
	R = np.array(gR)
	R_1_by_S2 = np.array(gR_1_by_S2)
	Color = np.array(gColor)
	Label = np.array(gLabel)
	Logg = np.array(gLogg)
	Logg_1_by_S2 = np.array(gLogg_1_by_S2)
	
	len = 10.67
	fig, axs = plt.subplot_mosaic([
			    ['M', 'Z', 'logg'],
			    ['age', 'Teff', 'R']
			], layout='constrained', sharex=False, figsize=(len,len/2))
	ax_M=axs['M']
	ax_R=axs['R']
	ax_Teff=axs['Teff']
	ax_Age=axs['age']
	ax_Z=axs['Z']
	ax_logg=axs['logg']

	max_1_by_S2 = np.max(Mass_1_by_S2)
	L = Mass_1_by_S2 == max_1_by_S2
	max_mass = Mass[L]
	max_R = R[L]
	max_Z = Z[L]
	max_Teff = Teff[L]
	max_Logg = Logg[L]
	max_Age = Age[L]

	for mass in range(190, 231, 1):
		L = Mass == mass/100
		one_by_S2_for_mass = Mass_1_by_S2[L]
		#print(mass/100, np.max(one_by_S2_for_mass))
	for z in range(5, 21, 1):
		L = Z == z/1000
		one_by_S2_for_Z = Z_1_by_S2[L]
		#print(z/1000, np.max(one_by_S2_for_Z))

	for a in range(400, 900, 1):
		L1 = Age < a/1000 + (0.5)/1000
		L2 = Age > a/1000 - (0.5)/1000
		on_by_S2_for_Age = Age_1_by_S2[L1 & L2]
		if on_by_S2_for_Age.size == 0:
			continue
		#print(a/1000, np.max(on_by_S2_for_Age))

	for r in range(2000, 2210, 1):
		L1 = R < r/1000 + (0.5)/1000
		L2 = R > r/1000 - (0.5)/1000
		on_by_S2_for_R = R_1_by_S2[L1 & L2]
		if on_by_S2_for_R.size == 0:
			continue
		#print(r/1000, np.max(on_by_S2_for_R))

	alpha=0.3
	size=5
	fs='xx-large'
	y_max=[]
	y_max.append(np.max(Mass_1_by_S2))
	ax_M.scatter(Mass, Mass_1_by_S2, c=Color, s=size, alpha=alpha)
	ax_M.set_ylabel("1/S$^2_m$", fontsize=fs)
	ax_M.set_yscale("log", nonpositive='clip')
	ax_M.set_xlabel("$M$" + ' ($M_{\odot}$)', fontsize=fs)
	if max_1_by_S2 > 10:
		ax_M.scatter(max_mass, max_1_by_S2, c='r', s=size+0.2)

	mass_gauss = [2.12, 0.12178259629627088, 1.0273297657497986, -1.919946498491527]
	x_line = np.linspace(1.9, 2.3, 100)
	y_line = Gaussian_model(x_line, mass_gauss)
	ax_M.plot(x_line, 10**y_line, 'r--', linewidth=2, alpha=0.6)
	y_max.append(10**np.max(y_line))

	
	ax_R.scatter(R, R_1_by_S2, c=Color, s=size, alpha=alpha)
	ax_R.set_ylabel("1/S$^2_m$", fontsize=fs)
	ax_R.set_xlabel("$R$" + ' ($R_{\odot}$)', fontsize=fs)
	ax_R.set_yscale("log", nonpositive='clip')
	if max_1_by_S2 > 10:
		ax_R.scatter(max_R, max_1_by_S2, c='r', s=size+0.2)
	R_gauss = [2.15445, 0.0300984519578766, 0.258047, -1.95] 
	x_line = np.linspace(2.05, 2.20, 100)
	x_line = x_line
	y_line = Gaussian_model(x_line, R_gauss)
	ax_R.plot(x_line, 10**y_line, 'r--', linewidth=2, alpha=0.6)
	y_max.append(10**np.max(y_line))
	
	ax_Teff.scatter(Teff, Teff_1_by_S2, c=Color, s=size, alpha=alpha)
	ax_Teff.set_ylabel("1/S$^2_m$", fontsize=fs)
	ax_Teff.set_xlabel(r"${T_{\rm eff}}$ (K)", fontsize=fs)
	ax_Teff.set_yscale("log", nonpositive='clip')
	if max_1_by_S2 > 10:
		ax_Teff.scatter(max_Teff, max_1_by_S2, c='r', s=size+0.2)
	
	ax_Age.scatter(Age, Age_1_by_S2, c=Color, s=size, alpha=alpha)
	ax_Age.set_ylabel("1/S$^2_m$", fontsize=fs)
	ax_Age.set_xlabel("$Age$ (Gyr)", fontsize=fs)
	ax_Age.set_yscale("log", nonpositive='clip')
	ax_Age.set_ylim(np.min(Age_1_by_S2), np.max(Age_1_by_S2)*2)
	if max_1_by_S2 > 10:
		ax_Age.scatter(max_Age, max_1_by_S2, c='r', s=size+0.2)
	age_gauss = [0.51176, 0.10905879318954945, 0.9312869210211539, -1.9758942446111494]
	x_line = np.linspace(np.min(Age), np.max(Age), 1000)
	y_line = Gaussian_model(x_line, age_gauss)
	ax_Age.plot(x_line, 10**y_line, 'r--', linewidth=2, alpha=0.6)
	y_max.append(10**np.max(y_line))

	lebel_enum = set(gLabel)
	if lebel_enum and min(lebel_enum) >= 0:
		labels = ["$f_1$"+"$\sim$"+"$l$=2, $f_2$"+"$\sim$"+"$l$=1.",
			"$f_1$, " +"$f_2$" +"$\sim$"+"$l$=1.",
			"$f_1$, " +"$f_2$" +"$\sim$"+"$l$=2."]
		for label in [0,1,2]:
			ax_Z.scatter(Z[Label==label][0], Z_1_by_S2[Label==label][0], c=Color[Label==label][0], s=size, label=labels[label])
		ax_Z.legend(loc='upper center', fontsize=13)

	ax_Z.scatter(Z, Z_1_by_S2, c=Color, s=size, alpha=alpha)
	ax_Z.set_ylabel("1/S$^2_m$", fontsize=fs)
	ax_Z.set_xlabel("$Z$", fontsize=fs)
	ax_Z.set_yscale("log", nonpositive='clip')
	if max_1_by_S2 > 10:
		ax_Z.scatter(max_Z, max_1_by_S2, c='r', s=size+0.2)
	ax_Z.xaxis.set_major_locator(MultipleLocator(0.005))
	ax_Z.xaxis.set_minor_locator(MultipleLocator(0.001))

	ax_logg.scatter(Logg, Logg_1_by_S2, c=Color, s=size, alpha=alpha)
	ax_logg.set_ylabel("1/S$^2_m$", fontsize=fs)
	ax_logg.set_xlabel("log$_{g}$" + " (cm$\cdot$s$^{-2}$)", fontsize=fs)
	ax_logg.set_yscale("log", nonpositive='clip')
	if max_1_by_S2 > 10:
		ax_logg.scatter(max_Logg, max_1_by_S2, c='r', s=size+0.2)
	
	ax_Age.set_ylim(np.min(Age_1_by_S2), np.max(y_max)*2) 
	ax_Teff.set_ylim(np.min(Teff_1_by_S2), np.max(y_max)*2)
	ax_R.set_ylim(np.min(R_1_by_S2), np.max(y_max)*2)
	ax_M.set_ylim(np.min(Mass_1_by_S2), np.max(y_max)*2)
	ax_Z.set_ylim(np.min(Mass_1_by_S2), np.max(y_max)*2)
	ax_logg.set_ylim(np.min(Mass_1_by_S2), np.max(y_max)*2)
	
	plt.show()



if __name__ == "__main__":
	
	filepath = os.path.join('.', 'outputs.rst')
	for dirpath, dirnames, filenames in os.walk(filepath):
		for filename in filenames:
			if filename[-5:] == ".data" and ('sample_' in filename or 'KIC_8703887' in filename):
				analysis_one(os.path.join(dirpath, filename))
	
	
	print("sample cnt={} ({}-{})".format(len(gMass), np.min(gMass), np.max(gMass)))
	plot_env()
